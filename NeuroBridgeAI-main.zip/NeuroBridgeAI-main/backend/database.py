
import os

from dotenv import load_dotenv
from pymongo import AsyncMongoClient

load_dotenv()

MONGODB_URI = os.getenv("MONGODB_URI")
MONGODB_DATABASE = os.getenv("MONGODB_DATABASE", "neurobridge")

if not MONGODB_URI:
    raise RuntimeError(
        "MONGODB_URI is missing. Configure it in the project .env file."
    )

client = AsyncMongoClient(
    MONGODB_URI,
    serverSelectionTimeoutMS=5000,
)

database = client[MONGODB_DATABASE]


async def check_database_connection():
    """Verify that MongoDB is reachable."""
    await client.admin.command("ping")
    return True


async def close_database_connection():
    """Close the MongoDB client cleanly."""
    await client.close()
