from fastapi.middleware.cors import CORSMiddleware
from fastapi import FastAPI
from backend.database import check_database_connection
app = FastAPI(
    title="NeuroBridge AI",
    description="Research framework for EEG signal analysis and explainable AI.",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "null",
        "http://127.0.0.1:5500",
        "http://localhost:5500",
        "http://127.0.0.1:8000",
        "http://localhost:8000",
    ],
    allow_credentials=False,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization"],
)

@app.get("/")
def home():
    return {
        "project": "NeuroBridge AI",
        "status": "running",
        "message": "Welcome to the NeuroBridge AI backend.",
    }


@app.get("/health")
def health_check():
    return {
        "status": "healthy",
        "service": "NeuroBridge AI API",
    }

@app.get("/health/database")
async def database_health_check():
    try:
        await check_database_connection()
        return {
            "status": "healthy",
            "database": "connected",
        }
    except Exception:
        return {
            "status": "unavailable",
            "database": "disconnected",
        }