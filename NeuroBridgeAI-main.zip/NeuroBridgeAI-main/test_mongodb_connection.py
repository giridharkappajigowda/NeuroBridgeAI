﻿import asyncio
from backend.database import check_database_connection, close_database_connection

async def main():
    try:
        await check_database_connection()
        print("SUCCESS: Connected to MongoDB Atlas.")
    except Exception as exc:
        print(f"CONNECTION FAILED: {type(exc).__name__}: {exc}")
    finally:
        await close_database_connection()

asyncio.run(main())
