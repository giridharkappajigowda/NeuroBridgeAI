
const API_BASE_URL = "http://127.0.0.1:8000";

async function checkBackend() {
    const apiStatus = document.getElementById("api-status");
    const backendMetric = document.getElementById("backend-metric");

    try {
        const response = await fetch(`${API_BASE_URL}/health`);

        if (!response.ok) {
            throw new Error(`HTTP error: ${response.status}`);
        }

        const data = await response.json();

        if (data.status !== "healthy") {
            throw new Error("Backend health check failed");
        }

        apiStatus.textContent = "Backend connected";
        backendMetric.textContent = "Online";

    } catch (error) {
        apiStatus.textContent = "Backend unavailable";
        backendMetric.textContent = "Offline";

        console.error("Backend connection error:", error);
    }
}

document.addEventListener("DOMContentLoaded", () => {
    checkBackend();
});
